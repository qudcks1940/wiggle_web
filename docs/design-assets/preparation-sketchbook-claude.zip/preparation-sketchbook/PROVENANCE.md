# 제작 및 사용 정보

- 날짜: 2026-09-09
- 방식: Codex 내장 ImageGen. 정확한 생성 프롬프트는 `prompts.json`.
- 입력: 사용자가 이 대화에서 선택한 3번 디자인 시안. 사본은 `reference/selected-option-3.png`.
- 두 생성물: 글자/버튼을 제거한 전체 장면, 크림색 배경의 오리·크레용 독립 일러스트.
- WebP 변환 및 작은 버전: sharp. PNG 원본 보존.
- 크기·바이트 수·불투명 여부·SHA-256·생성 원본 위치: `manifest.json`.
- 원본 generated_images 경로는 출처 기록이다. 서비스에서는 assets 폴더 파일을 프로젝트 public 경로로 복사해 사용한다.
- 독립 일러스트는 투명 배경이 아니다. PNG라는 확장자를 투명의 근거로 해석하지 않는다.
